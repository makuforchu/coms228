package hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

/*
 * @author MakuForchu
 */
public class MsgTree {
	
	/*
	 * holds the value of the encoding string which the cursor is on
	 */
	public char payloadChar;
	
	/*
	 * holds the left side of the tree
	 */
	public MsgTree left;
	
	/*
	 * holds the right side of the tree
	 */
	public MsgTree right;
	
	/*
	 * A stack that stores the letters as objects from the input string 
	 * and turns them into  tree
	 */
	public Stack <MsgTree> stack;

	/*
	 * This constructor builds the tree from a string
	 * It iterates through a string and pushes the non '^' to the stack
	 * and makes them to a string when it finds a '^'
	 */
	public MsgTree(String encodingString) {

		if (encodingString == null) {
			throw new NullPointerException();
		}
		
		else {
			stack = new Stack<>();
			for (int i = encodingString.length()-1; i >= 0; i--) {
				payloadChar = encodingString.charAt(i);
				MsgTree tree = new MsgTree(payloadChar);
				
				if (payloadChar != '^') {
					stack.push(tree);
				}
				else {
					tree.left = stack.pop();
					tree.right = stack.pop();
					this.left = tree.left;
					this.right = tree.right;			
					stack.push(tree);	
				}
				
			}
			
		}

	}
	/*
	 * This constructor works for a single node with null children
	 * @param payloadchar
	 */
	public MsgTree(char payloadChar) {
		this.payloadChar = payloadChar;
		left = null;
		right = null;
			
	}
	
	/*
	 * method to print characters and their binary codes
	 * @param root
	 * @param code
	 */
	
	public static void printCodes(MsgTree root, String code) {
		
		if (root == null) {
			return;
		}
		if (root.payloadChar != '^') {
			System.out.println(root.payloadChar + "              " + code);
		}
		
			printCodes(root.left, code + "0");
			printCodes(root.right, code + "1");
		

		
	}

	/*
	 * method to decode the message
	 * takes in the 1s and 0s and maps through the tree to find the character the code represents
	 * @param codes
	 * @param msg
	 */
	public static void decode(MsgTree codes, String msg) {
		
		MsgTree temp = codes;
		for (int i = 0; i < msg.length(); i++){
			if ( msg.charAt(i) == '0' && temp.left != null) {
				temp = temp.left;
			}
			else if ( msg.charAt(i) == '1' && temp.right != null) {
				temp = temp.right;
			}
			if (temp.payloadChar != '^'){
				System.out.print(temp.payloadChar);
				temp = codes;
			}
		}
		
		
	}

	/*
	 * Reads the file and prints out the character and their representative code in a table
	 * Also prints out the message hidden in the codes
	 */
	public static void main(String[] args) throws FileNotFoundException {

		Scanner scnr = new Scanner(System.in);
		String fileName;
		System.out.print("Please enter file name to decode: ");
		fileName = scnr.next();
		scnr = new Scanner(new File(fileName));
		String code = scnr.nextLine();
		String msg = scnr.nextLine();
		if (scnr.hasNextLine()) {
			code += '\n';
			code += msg;
			msg = scnr.nextLine();
		}
		scnr.close();
		System.out.println("\nCharacter      code");
		System.out.println("-----------------------");
		String output = "";
		MsgTree tree = new MsgTree(code);
		printCodes(tree.stack.pop(), output);
		System.out.println("\nMESSAGE:");
		decode(tree, msg);
	}
}
